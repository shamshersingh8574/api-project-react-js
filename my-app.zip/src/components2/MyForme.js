import React, { useState } from 'react'

import "./forme.css";
import { useFormik } from 'formik';
import * as Yup from 'yup';

const initialValues = {
    fname: '',
    lname: '',
    email: '',
    // channel: '',
    mobile: '',
    // password: '',
    // confirm_password: '',
}

const validationSchema = Yup.object({
    fname: Yup.string().min(2).required("Required!"),
    lname: Yup.string().min(2).required("Required!"),

    email: Yup.string().email('invalid email formate ').required("Required!"),
    // channel: Yup.string().required("Required!"),
    mobile: Yup.string().min(10).max(10).required("Required!"),
    // password: Yup.string().min(6).required("Required"),
    // confirm_password: Yup.string().required("Required").oneOf([Yup.ref('password'), null,], "password must match"),
})
export const MyForm = () => {

    const [allUser, setAllUser] = useState([]);
   

    const formik = useFormik({
        initialValues,
        validationSchema,
        onSubmit: (values, action) => {
            
            allUser.push(values)
            console.log(values)
            
            action.resetForm();
        }
        //    validate,

    })
    console.log('form errors', formik.errors);

    const onDeleteUser = (users) => {
        console.log(users)
        setAllUser(allUser.filter((user)=>user.email!=users.email))
    }
    const onEditUser=(user)=>{
        
        // const tempData = tableData[user]
        // setInputs
        // console.log(user);

    }
    return (
        <div className='container'>

            <div style={{ width: "50%" }}>
                <form onSubmit={formik.handleSubmit}>
                    <div className='main-form'>
                        <div className='all-label-input'>
                            <label htmlFor='fname'>First Name</label>
                            <input type='text' id='fname' name='fname'

                                {...formik.getFieldProps('fname')}
                            
                                // value={fname} required onChange={(e)=>setFname(e.target.value)}
                            />

                            {formik.touched.fname && formik.errors.fname ? (
                                <div className='error'>{formik.errors.fname}</div>
                            ) : null}
                        </div>

                        <div className='all-label-input'>
                            <label htmlFor='lname'>Last Name</label>
                            <input type='text' id='lname' name='lname'
    
                                {...formik.getFieldProps('lname')}
                            
                                // value={lname} required onChange={(e)=>setLname(e.target.value)}
                            />

                            {formik.touched.lname && formik.errors.lname ? (
                                <div className='error'>{formik.errors.lname}</div>
                            ) : null}
                        </div>

                        <div className='all-label-input'>
                            <label htmlFor='email'>E-mail</label>
                            <input type='email' id='email' name='email'

                                {...formik.getFieldProps('email')}
                                // value={email} required onChange={(e)=>setEmail(e.target.value)}
                            />
                            {formik.touched.email && formik.errors.email ? (
                                <div className='error'>{formik.errors.email}</div>
                            ) : null}

                        </div>

                        <div className='skills'>
                            <div>
                                <label htmlFor='email' style={{fontSize:"20px"}}>Skills</label>

                            </div>
                            <div>
                                <select name="cars" id="cars" style={{fontSize:"20px"}}>
                                    <option value="HTML">HTML</option>
                                    <option value="CSS">CSS</option>
                                    <option value="CSS3">CSS3</option>
                                    <option value="JQuery">JQuery</option>
                                    <option value="React">React</option>
                                    <option value="Javascript">Javascript</option>
                                </select>
                            </div>

                        </div>


                        <div className='all-label-input'>
                            <label htmlFor='mobile'>Mobile no</label>
                            <input type='number' id='mobile' name='mobile'

                                {...formik.getFieldProps('mobile')}
                            />
                            {formik.touched.mobile && formik.errors.mobile ? (
                                <div className='error'>{formik.errors.mobile}</div>
                            ) : null}

                        </div>

                        
                        <button type='submit'>Submit</button>
                    </div>
                </form>
            </div>

            <div className='myTable' >
                <table>
                    <tr>
                        <th>FastName</th>
                        <th>LastName</th>
                        <th>Email</th>
                        <th>Contact</th>
                        <th>Edit</th>
                        <th>Delete</th>


                    </tr>
                    {allUser.map((user, i) => (
                        <tr>
                            <td>{user.fname}</td>
                            <td>{user.lname}</td>
                            <td>{user.email}</td>
                            <td>{user.mobile}</td>
                            <td><button onClick={() => { onEditUser(user) }}>Edit</button></td>
                            <td><button onClick={() => { onDeleteUser(user) }}>Delete</button></td>

                        </tr>
                    ))}

                </table>
            </div>
        </div>
    )
}
