import React from 'react'
import { MyForm } from './MyForme'

export const App = () => {
  return (
    <div>
        <MyForm/>
    </div>
  )
}
