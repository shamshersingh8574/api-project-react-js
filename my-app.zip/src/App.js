import React from 'react'
import { ApiData } from './Component/ApiData'
import { FomeModel } from './Component/FomeModel'

export const App = () => {
  return (
    <div>
      <ApiData/>
      {/* <FomeModel/> */}
    </div>
  )
}
