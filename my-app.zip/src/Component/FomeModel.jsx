import React from 'react'

export const FomeModel = ({item,cancelButton}) => {

  return (
    <div className='fomeContainer'>
        <form className='formWrapper'>
    <div className='row'>
      <div className='col-25'>
        <label for="fname"> Name</label>
      </div>
      <div className='col-75'>
        <input type="text" id="props.name"  placeholder="Your name.." value={item.name}/>
      </div>
    </div>
    <div className='row'>
      <div className='col-25'>
        <label for="lname">Email</label>
      </div>
      <div className='col-75'>
        <input type="email" id="email"  placeholder="email" value={item.email}/>
      </div>
    </div>
    <div className='row'>
      <div className='col-25'>
        <label for="phone">Phone</label>
      </div>
      <div className='col-75'>
        <input type="text" id="phone" name="" placeholder="phone" value={item.phone}/>
      </div>
    </div>

    <div className='row'>
      <div className='col-25'>
        <label for="lname">Website</label>
      </div>
      <div className='col-75'>
        <input type="text" id="website" name="lastname" placeholder=" website" value={item.website}/>
      </div>
    </div>

    <button onClick={cancelButton}>ok</button>
    
  </form>
    </div>

  )
}
