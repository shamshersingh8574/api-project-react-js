import React, { useEffect, useState } from 'react'
import axios from 'axios'
import "./style.css";
import { BiEnvelope } from "react-icons/bi";
import { MdCall } from "react-icons/md";
import { SiAiohttp } from "react-icons/si";
import { BsHeart } from "react-icons/bs";
import { RxPencil2 } from "react-icons/rx";
import { AiOutlineDelete } from "react-icons/ai";
import { FomeModel } from './FomeModel';

export const ApiData = () => {
    const [userData, setUserData] = useState([]);
    const [showModel, setShowModel] = useState(false);
    const [selectedUser, setSelectedUser] = useState();
    useEffect(() => {
        axios
            .get("https://jsonplaceholder.typicode.com/users")
            .then((res) => {
                console.log(res.data);
                setUserData(res.data)
            })
            .catch(() => {
                console.log("api error");
            })
    }, []);

    function Myfunction(item) {
        setSelectedUser(item);
        setShowModel(true);
    }

    function cancelButton() {
        setShowModel(false);
    }
    return (
        <div className='Api_body' >
            {
                showModel &&
                <FomeModel item={selectedUser} cancelButton={cancelButton} />

            }
            {
                userData.slice(0, 8).map((item) => {
                    const { id, name, email, phone, website, username } = item;
                    return (<div onClick={() => { Myfunction(item) }} className='' key={id}>


                        <div className='container'>
                            <div className='icon icon11'><img src={`https://avatars.dicebear.com/v2/avataaars/${username}.svg?options[mood][]=happy`} alt="" /></div>

                            <div className=' icon1'>{name}</div>
                            <div className='icon icon2'><BiEnvelope /></div>
                            <div className='md_name icon3'>{email}</div>
                            <div className='icon icon4'><MdCall /></div>
                            <div className='md_name icon5'>{phone}</div>
                            <div className='icon icon6'><SiAiohttp /></div>
                            <div className='md_name icon7'>{website}</div>
                            <div className=' icon8'><BsHeart /></div>
                            <div className=' icon9'><RxPencil2 /></div>
                            <div className=' icon10'><AiOutlineDelete /></div>
                        </div>


                    </div>)

                })
            }

        </div>
    )
}
